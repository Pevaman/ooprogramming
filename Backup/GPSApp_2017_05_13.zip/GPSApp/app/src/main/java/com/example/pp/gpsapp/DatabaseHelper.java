package com.example.pp.gpsapp;
/**
 * crea il database e usa le query per gestirlo
 */

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.sql.Time;
import java.util.Calendar;

//usa le virgolette solo nelle stringhe
public class DatabaseHelper extends SQLiteOpenHelper {

    static final String dbName = "Statistiche";

    public DatabaseHelper(Context context) {
        super(context, dbName, null, 1);
    }
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE Utente (\n" +
                "  IDUtente INT NOT NULL,\n" +
                "  Nome VARCHAR(45) NULL,\n" +
                "  Cognome VARCHAR(45) NULL,\n" +
                "  Sesso tinyint NULL,\n" +
                "  Altezza INT NULL,\n" +
                "  Peso INT NULL,\n" +
                "  Data DATE NULL,\n" +
                "  PRIMARY KEY (IDUtente))");
            //sesso=1 è uomo
        db.execSQL("CREATE TABLE Attività (\n" +
                "  Data DATETIME NOT NULL,\n" +
                "  Durata LONG NULL,\n" +
                "  Distanza DOUBLE NULL,\n" +
                "  Calorie DOUBLE NULL,\n" +
                "  Velocità_media DOUBLE NULL,\n" +
                "  PRIMARY KEY (data))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
    //sesso=1 è uomo
    public void insertUtente(int id,  String nome, String cognome, int sesso, int altezza, int peso,int d,int m,int y){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("INSERT INTO Utente (IDUtente, Nome, Cognome, Sesso, Altezza, Peso, Data) VALUES " +
                "('"+id+"', '"+nome+"', '"+cognome+"', '"+sesso+"', '"+altezza+"', '"+peso+"','"+y+"-"+m+"-"+d+"');");
    }

    public void insertAttività(int Y,int M,int D,int H,int Min,int S, long durata, double lungPerc, double calorie, double velmed){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("INSERT INTO Attività (Data,Durata,Distanza, Calorie, Velocità_media)" +
                " VALUES('"+Y+"-"+M+"-"+D+" "+H+":"+Min+":"+S+"', "+durata+","+lungPerc+","+calorie+","+velmed+");");
    }

    public void updateUtente(int id, String nome, String cognome, boolean sesso, int altezza, int peso){

        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("UPDATE Utente SET Nome="+nome +", Cognome="+cognome +", Sesso="+sesso +", Altezza="+altezza +", Peso="+peso +"  WHERE IDUtente="+id +";");
    }
    public int selectUtente(){
        SQLiteDatabase db = this.getWritableDatabase();
        int id=-1;
        Cursor cur=db.rawQuery("SELECT IDUtente, Peso FROM Utente",null);
        if (cur.moveToFirst()){
            do{
               id=cur.getInt(cur.getColumnIndex("IDUtente"));
            }while(cur.moveToNext());
        }
        cur.close();
        return id;
    }
    public String selectNome(){
        SQLiteDatabase db = this.getWritableDatabase();
        String s="John";
        Cursor cur=db.rawQuery("SELECT Nome FROM Utente",null);
        if (cur.moveToFirst()){
            do{
                s=cur.getString(cur.getColumnIndex("Nome"));
            }while(cur.moveToNext());
        }
        cur.close();
        return s;
    }
    public int selectWeight(){
        SQLiteDatabase db = this.getWritableDatabase();
        int weight=70;
        Cursor cur=db.rawQuery("SELECT Peso FROM Utente",null);
        if (cur.moveToFirst()){
            do{
                try {
                    weight = cur.getInt(cur.getColumnIndex("Peso"));   //cur.getColumnIndex("Peso")
                }catch(IllegalStateException ise){

                }
            }while(cur.moveToNext());
        }
        cur.close();
        return weight;
    }
    /*ho un array di stringhe con yy mm dd*/
    public String[] selectDate(){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] ret;
        String d="";
        Cursor cur=db.rawQuery("SELECT Data FROM Utente",null);
        if (cur.moveToFirst()){
            do{
                try {
                    d=cur.getString(cur.getColumnIndex("Data"));
                }catch(IllegalStateException ise){

                }
            }while(cur.moveToNext());
        }
        cur.close();
        ret=d.split("-");
        return ret;
    }
    public ActivityClass[] selectAllActivity(){
        //calcolo il numero di attività presenti nel database
        int n=0;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cur=db.rawQuery("SELECT count(Data) as Numero FROM Attività",null);
        if (cur.moveToFirst()){
            do{
                try {
                    n=cur.getInt(cur.getColumnIndex("Numero"));
                }catch(IllegalStateException ise){

                }
            }while(cur.moveToNext());
        }
        //riempio un array di attività
        ActivityClass[] ret=new ActivityClass[n];
        int i=0;
        if (cur.moveToFirst()){
            do{
                try {
                    ret[i].setDateTime(cur.getString(cur.getColumnIndex("Data")));
                    ret[i].setDuration(cur.getLong(cur.getColumnIndex("Durata")));
                    ret[i].setDistance(cur.getDouble(cur.getColumnIndex("Distanza")));
                    ret[i].setCalories(cur.getDouble(cur.getColumnIndex("Calorie")));
                    ret[i].setAvgSpeed(cur.getDouble(cur.getColumnIndex("Velocità_media")));
                    i++;
                }catch(IllegalStateException ise){

                }
            }while(cur.moveToNext());
        }
        cur.close();
        return ret;
    }
    public String prova(){
        SQLiteDatabase db = this.getWritableDatabase();
        String prova="ERRORE";
        Cursor cur=db.rawQuery("SELECT * FROM Utente",null);
        if (cur.moveToFirst()){
            do{
                try {
                    prova=cur.getString(cur.getColumnIndex("Cognome"));
                }catch(IllegalStateException ise){

                }
            }while(cur.moveToNext());
        }
        cur.close();
        return prova;
    }
    public void reset(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from Utente");
        db.execSQL("delete from Attività");
    }
}