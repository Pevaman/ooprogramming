package com.example.pp.gpsapp;
/**
*questa classe crea il form e ne preleva i dati
 */
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Intent;
import java.util.Calendar;
import android.os.Build;
import android.os.Bundle;
import android.app.Activity;
import android.support.annotation.RequiresApi;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static java.security.AccessController.getContext;

public class FormActivity extends Activity {
    private DatabaseHelper db;
    private EditText nome;
    private EditText  cognome;
    private CheckBox uomo;
    private CheckBox donna;
    private EditText  altezza;
    private EditText  peso;
    private Button submit;
    private DatePicker datePicker;
    private Calendar calendar;
    private int year;
    private int month;
    private int day;
    private TextView tvDisplayDate;
    private DatePicker dpResult;
    private Button btnChangeDate;
    static final int DATE_DIALOG_ID = 999;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);
        //inizializzo cose
        setCurrentDateOnView();
        addListenerOnButton();
        Intent myIntent = new Intent(FormActivity.this, MapsActivity.class);
        db =new DatabaseHelper(FormActivity.this);
        nome=(EditText)findViewById(R.id.nome);
        cognome=(EditText)findViewById(R.id.cognome);
        uomo=(CheckBox)findViewById(R.id.uomo);
        donna=(CheckBox)findViewById(R.id.donna);
        altezza=(EditText)findViewById(R.id.altezza);
        peso=(EditText)findViewById(R.id.peso);
        submit=(Button)findViewById(R.id.submit);
        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        int idUtente=db.selectUtente();
        //se trova un utente può passare subito all'activity principale
        if(idUtente>=0) {
            FormActivity.this.startActivity(myIntent);
        }
        submit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(
                        getApplicationContext(),
                        MapsActivity.class
                );
                intent.putExtra("database", String.valueOf(db));
                int boolUomo=1;
                if(donna.isActivated()){
                    boolUomo=0;
                }
                try {
                    db.insertUtente(1, nome.getText().toString(), cognome.getText().toString(),
                            boolUomo, Integer.parseInt(altezza.getText().toString()), Integer.parseInt(peso.getText().toString()),
                            day,month,year);
                }catch(NumberFormatException nfe){}
                startActivity(intent);
            }
        });
    }
    public void setCurrentDateOnView() {

        tvDisplayDate = (TextView) findViewById(R.id.tvDate);
        //dpResult = (DatePicker) findViewById(R.id.dpResult);

        final Calendar c = Calendar.getInstance();
        year = c.get(Calendar.YEAR);
        month = c.get(Calendar.MONTH);
        day = c.get(Calendar.DAY_OF_MONTH);

        // set current date into textview
        tvDisplayDate.setText(new StringBuilder()
                // Month is 0 based, just add 1
                .append(month + 1).append("-").append(day).append("-")
                .append(year).append(" "));

        // set current date into datepicker
//        dpResult.init(year, month, day, null);

    }

    public void addListenerOnButton() {

        btnChangeDate = (Button) findViewById(R.id.btnChangeDate);

        btnChangeDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                showDialog(DATE_DIALOG_ID);

            }

        });

    }

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DATE_DIALOG_ID:
                // set date picker as current date
                return new DatePickerDialog(this, datePickerListener,
                        year, month,day);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener datePickerListener
            = new DatePickerDialog.OnDateSetListener() {

        // when dialog box is closed, below method will be called.
        public void onDateSet(DatePicker view, int selectedYear,
                              int selectedMonth, int selectedDay) {
            year = selectedYear;
            month = selectedMonth;
            day = selectedDay;

            // set selected date into textview
            tvDisplayDate.setText(new StringBuilder().append(month + 1)
                    .append("-").append(day).append("-").append(year)
                    .append(" "));

            // set selected date into datepicker also
//            dpResult.init(year, month, day, null);

        }
    };
}

