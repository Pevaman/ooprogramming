package com.example.pp.gpsapp;

import java.sql.Time;
import java.util.Calendar;

/**
 * Created by pP on 13/05/2017.
 * classe per gestire le attività svolte
 */

public class ActivityClass {
    private String dateTime;
    private long duration;
    private double distance;
    private double calories;
    private double avgSpeed;

    public ActivityClass(String d, long duration, double distance, double calories, double avgSpeed) {
        this.dateTime = d;
        this.duration = duration;
        this.distance = distance;
        this.calories = calories;
        this.avgSpeed = avgSpeed;
    }

    public ActivityClass() {
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String d) {
        this.dateTime = d;
    }


    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public double getCalories() {
        return calories;
    }

    public void setCalories(double calories) {
        this.calories = calories;
    }

    public double getAvgSpeed() {
        return avgSpeed;
    }

    public void setAvgSpeed(double avgSpeed) {
        this.avgSpeed = avgSpeed;
    }
    public String getAll(){
        String ret="";
        ret="data e ora: "+dateTime+ "\n"
                + "duration: "+ String.valueOf(duration)+ "\n"
                + "distance "+String.valueOf(distance)+ "\n"
                + "calories: "+String.valueOf(calories)+ "\n"
                + "avgSpeed: "+String.valueOf(avgSpeed)+ "\n";
        return ret;
    }
}
