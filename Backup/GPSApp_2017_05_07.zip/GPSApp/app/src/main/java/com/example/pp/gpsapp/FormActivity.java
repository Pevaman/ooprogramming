package com.example.pp.gpsapp;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import static android.R.attr.value;

public class FormActivity extends Activity {
    private DatabaseHelper db;
    private EditText nome;
    private EditText  cognome;
    private EditText  sesso;
    private EditText  altezza;
    private EditText  peso;
    private Button submit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);
        //inizializzo cose
        Intent myIntent = new Intent(FormActivity.this, MapsActivity.class);
        db = new DatabaseHelper(this);
        nome=(EditText)findViewById(R.id.nome);
        cognome=(EditText)findViewById(R.id.cognome);
        sesso=(EditText)findViewById(R.id.sesso);
        altezza=(EditText)findViewById(R.id.altezza);
        peso=(EditText)findViewById(R.id.peso);
        submit=(Button)findViewById(R.id.submit);
        int idUtente=db.selectUtente();
        //se trova un utente può passare subito all'activity principale
        if(idUtente>=0) {
            FormActivity.this.startActivity(myIntent);
        }
        submit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(
                        getApplicationContext(),
                        MapsActivity.class
                );
                boolean uomo=true;
                if(sesso.getText().toString().equals("donna")){
                    uomo=false;
                }
                db.insertUtente(0,nome.getText().toString(),cognome.getText().toString(),
                        uomo,Integer.parseInt(altezza.getText().toString()),Integer.parseInt(peso.getText().toString()));
                startActivity(intent);
            }
        });
    }
}
