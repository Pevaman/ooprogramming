package com.example.pp.gpsapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.widget.TextView;
import android.widget.Toast;


/**
 * rappresenta i dati di un attività
 */

public class Data {
    float distance; //in meters
    float speed;
    float averageSpeed;
    int calorie;
    private Activity activity;
    private TextView text;
    private final Context mContext;

    public Data(Activity _activity,Context mContext) {
        this.activity=_activity;
        this.mContext = mContext;
        text = (TextView)this.activity.findViewById(R.id.testData);
        distance=0;
        speed=0;
        averageSpeed = 0;
        calorie=0;
    }
    public void setDistance(float d){
        distance=d;
    }
    public void sumDistance(float d){
        distance=distance+d;
        setText();
    }
    public void testText(TextView t){
        text=t;
    }
    public void setText(){
        text.setText(Float.toString(distance));
        //Toast.makeText(mContext, Float.toString(distance), Toast.LENGTH_SHORT).show();
    }
    public void resetDist(){
        distance=0;
    }
}
