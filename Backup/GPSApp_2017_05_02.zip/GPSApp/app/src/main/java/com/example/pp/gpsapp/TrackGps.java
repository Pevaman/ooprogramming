package com.example.pp.gpsapp;

/**
 * Created by pP on 24/04/2017.
 */

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import static android.location.LocationManager.GPS_PROVIDER;
import static android.location.LocationProvider.AVAILABLE;
import static android.location.LocationProvider.OUT_OF_SERVICE;
import static android.location.LocationProvider.TEMPORARILY_UNAVAILABLE;

public class TrackGps extends Service implements LocationListener {

    private boolean startActivity = false;
    private final Context mContext;
    private GoogleMap mMap;
    boolean checkGPS = false;
    boolean checkNetwork = false;
    boolean canGetLocation = false;
    Location loc;
    Location previousLocation=new Location("");
    boolean prev = false;   //per gestire previous location
    double latitude;
    double longitude;
    private ArrayList<LatLng> points = new ArrayList<LatLng>();
    private Polyline line;
    private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 1;
    private static final long MIN_TIME_BW_UPDATES = 1000;
    protected LocationManager locationManager;
    private Data data;

    public TrackGps(Context mContext) {
        this.mContext = mContext;
        getLocation();
    }

    private Location getLocation() {
        try {
            locationManager = (LocationManager) mContext
                    .getSystemService(LOCATION_SERVICE);

            // getting GPS status
            checkGPS = locationManager
                    .isProviderEnabled(GPS_PROVIDER);

            // getting network status
            checkNetwork = locationManager
                    .isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            if (!checkGPS){
                showSettingsGps();
            }
          /*  if (!checkNetwork){
                showSettingsNetwork();
            }*/

            // if GPS Enabled get lat/long using GPS Services
           // if (checkGPS) {
              //  Toast.makeText(mContext, "GPS", Toast.LENGTH_SHORT).show();
            //    if (loc == null) {
                    try {
                        locationManager.requestLocationUpdates(
                                GPS_PROVIDER,
                                MIN_TIME_BW_UPDATES,
                                MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
                        Log.d("GPS Enabled", "GPS Enabled");
                        if (locationManager != null) {
                            loc = locationManager
                                    .getLastKnownLocation(GPS_PROVIDER);
                            if (loc != null) {
                                latitude = loc.getLatitude();
                                longitude = loc.getLongitude();
                            }
                        }
                    } catch (SecurityException e) {

                    }
              //  }
          //  }

            // get location from Network Provider
           // if (checkNetwork) {
           //     Toast.makeText(mContext, "Network", Toast.LENGTH_SHORT).show();
                try {
                    locationManager.requestLocationUpdates(
                            LocationManager.NETWORK_PROVIDER,
                            MIN_TIME_BW_UPDATES,
                            MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
                    Log.d("Network", "Network");
                    if (locationManager != null) {
                        loc = locationManager
                                .getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                    }

                    if (loc != null) {
                        latitude = loc.getLatitude();
                        longitude = loc.getLongitude();
                    }
                } catch (SecurityException e) {

                }


        //    }
            //se non è ancora attivo gps e network non fa un cazzo
            if (!checkGPS && !checkNetwork) {
                Toast.makeText(mContext, "No Service Provider Available", Toast.LENGTH_SHORT).show();
            } else {
                this.canGetLocation = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return loc;
    }

    public double getLongitude() {
        if (loc != null) {
            longitude = loc.getLongitude();
        }
        return longitude;
    }

    public double getLatitude() {
        if (loc != null) {
            latitude = loc.getLatitude();
        }
        return latitude;
    }

    public boolean canGetLocation() {
        return this.canGetLocation;
    }

    public void showSettingsGps() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(mContext);

        alertDialog.setTitle("GPS Not Enabled");
        alertDialog.setMessage("You need GPS to reach your location. Do you wants to turn on GPS?");
        alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                mContext.startActivity(intent);
            }
        });
        alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        alertDialog.show();
    }

    public void showSettingsNetwork() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(mContext);

        alertDialog.setTitle("Network Not Enabled");
        alertDialog.setMessage("Do you wants to turn On Network. GPS may be out of reach in closed places.");
        alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Settings.ACTION_DATA_ROAMING_SETTINGS);
                mContext.startActivity(intent);
            }
        });
        alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        alertDialog.show();
    }

    public void stopUsingGps() {
        if (locationManager != null) {

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            locationManager.removeUpdates(TrackGps.this);
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();
        LatLng latLng = new LatLng(latitude, longitude);
        Location loc=new Location("");
        loc.setLatitude(latitude);
        loc.setLongitude(longitude);
        /*if (loc.hasAltitude()){
            Toast.makeText(mContext, "tiene l'altitudine", Toast.LENGTH_SHORT).show();
        }*/
        //per test
      /*  float dist=0;
        if(prev==true){
            dist=loc.distanceTo(loc2);
            //data.sumDistance(dist);
        }
        prev=true;
        String prova= DateFormat.getTimeInstance().format(new Date());
        new AlertDialog.Builder(mContext)
                .setTitle("ultimo update")
                .setMessage(prova+" "+loc.getLatitude()+" "+dist)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // continue with delete
                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // do nothing
                    }
                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();*/
        //Toast.makeText(mContext, "GPS "+locationManager.getProvider(LocationManager.GPS_PROVIDER).getAccuracy(), Toast.LENGTH_SHORT).show();
        //Toast.makeText(mContext, "NETWORK "+locationManager.getProvider(LocationManager.NETWORK_PROVIDER).getAccuracy(), Toast.LENGTH_SHORT).show();
        //fine test
        points.add(latLng);
        if(startActivity==true && prev==true) {
            sendData(loc);
        }
        //setto locazione precedente
        prev=true;
        previousLocation.setLatitude(loc.getLatitude());
        previousLocation.setLongitude(loc.getLongitude());
        previousLocation.set(loc);
        redrawLine();
    }

    public void redrawLine(){
        mMap.clear();  //clears all Markers and Polylines

        PolylineOptions options = new PolylineOptions().width(35).color(Color.GREEN).geodesic(true);
        for (int i = 0; i < points.size(); i++) {
            LatLng point = points.get(i);
            options.add(point);
        }
        addMarker(mMap,points.get(points.size()-1)); //add Marker in current position
        if(startActivity) {
            line = mMap.addPolyline(options); //add Polyline
        }
    }
    public void addMarker(GoogleMap map, LatLng curLoc){
        map.addMarker(new MarkerOptions().position(curLoc).title("You are here").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
        map.moveCamera(CameraUpdateFactory.newLatLng(curLoc));
    }

    public void sendData(Location l) {
        double dist;
        double speed;
        double cal=0;
        double VO2=0;
        if(prev==true){
            dist=previousLocation.distanceTo(l);
            data.sumDistance(dist/1000);
            speed=(dist/(MIN_TIME_BW_UPDATES/1000))*3.6;
            //cal=0.9*data.getWeight()*data.getDistance();
            //cal=data.getWeight()*9.8*data.getTime();  //il 9.8 si basa sui MET chart
            VO2=0.2*data.getSpeed()+3.5;
            cal=(5*data.getWeight()*VO2/1000)*data.getTime();
            data.setCalorie(cal);
            data.setSpeed(speed);
            //data.Altitude(loc);
            data.setText();
        }
    }

    public GoogleMap getMap(){
        return mMap;
    }
    public void setMap(GoogleMap gm){
        mMap=gm;
    }
    public void setStartActivity(boolean flag){
        startActivity=flag;
    }

    public void clearPoints(){
        points.clear();
    }

    public void clearPolyLines(){
        try {
            line.remove();
        }catch(NullPointerException npe){

        }
    }
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {
        if (GPS_PROVIDER.equals(s) && (i==TEMPORARILY_UNAVAILABLE || i==OUT_OF_SERVICE)){
            Toast.makeText(mContext, "GPS unavailable :(", Toast.LENGTH_SHORT).show();
        }
        if (GPS_PROVIDER.equals(s) && i==AVAILABLE){
            Toast.makeText(mContext, "GPS available :D", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onProviderEnabled(String s) {
        if(GPS_PROVIDER.equals(s)){
            mMap.animateCamera( CameraUpdateFactory.zoomTo( 18.0f ) );
        }
    }

    @Override
    public void onProviderDisabled(String s) {
        if(GPS_PROVIDER.equals(s)) {
            showSettingsGps();
        }
    }

    public void setPreviousLocationNull(){
        previousLocation=new Location("");
    }

    public void setObjectData(Activity _activity, Context mContext){
        data = new Data(_activity,mContext);
    }
    public void resetData(){
        data.resetData();
    }
    public void setPrev(boolean flag){
        prev=flag;
    }
    public void buttonOn(){
        setStartActivity(true);
        setPrev(false);
        clearPoints();
        setPreviousLocationNull();
        resetData();
        timeOn();
    }
    public void buttonOff(){
        setStartActivity(false);
        clearPoints();
        clearPolyLines();
        setPreviousLocationNull();
        setPrev(false);
        timeOff();
    }
    public void timeOn(){
        data.timeOn();
    }
    public void timeOff(){
        data.timeOff();
    }
}

