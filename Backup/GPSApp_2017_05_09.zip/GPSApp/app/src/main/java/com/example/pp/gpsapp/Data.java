package com.example.pp.gpsapp;

import android.app.Activity;
import android.content.Context;
import android.os.SystemClock;
import android.widget.Chronometer;
import android.widget.TextView;
import android.widget.Toast;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * rappresenta i dati di un attività
 */

public class Data {
    private double distance; //in kilometers
    private double speed; //in km/h
    private float averageSpeed; //serve database
    private double calories;
    private double altitude;
    private int ascent; //salita
    private int descent; //discesa
    private int weight;
    private Chronometer time;
    private Activity activity;
    private TextView text;
    private final Context mContext;
    private String prova;
    private int idUt;

    public Data(Activity _activity,Context mContext) {
        this.activity=_activity;
        this.mContext = mContext;
        text = (TextView)this.activity.findViewById(R.id.testData);
        time=(Chronometer)this.activity.findViewById(R.id.chronometer);
        distance=0;
        speed=0;
        averageSpeed = 0;
        calories=0;
        altitude=0;
        ascent=0;
        descent=0;
        weight=70;

        //Toast.makeText(mContext, String.valueOf(db.selectUtente()), Toast.LENGTH_SHORT).show();
        //Toast.makeText(mContext, db.prova(), Toast.LENGTH_SHORT).show();
    }
    public void setDistance(double d){
        distance=d;
    }
    public void sumDistance(double d){
        distance=distance+d;
    }
    public void testText(TextView t){
        text=t;
    }
    public void setText(){

        speed = BigDecimal.valueOf(speed)   //imposto le cifre decimali
                .setScale(1, RoundingMode.HALF_UP)
                .doubleValue();
        distance = BigDecimal.valueOf(distance)   //imposto le cifre decimali
                .setScale(3, RoundingMode.HALF_UP)
                .doubleValue();
        text.setText("distance: "+distance+" Km\n");
        text.append("speed: "+speed+" Km/h\n");
        text.append("calories: "+(int)calories+" kcal\n");
        text.append("weight: "+weight+" kg\n");
        //text.append("altitude: "+altitude+" m\n");
    }
    public void resetData(){
        distance=0;
        speed=0;
        calories=0;
    }
    public void setSpeed(double s){
        speed=s;
    }

    public void timeOn(){
        time.setBase(SystemClock.elapsedRealtime());
        time.start();
        time.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
            @Override
            public void onChronometerTick(Chronometer chronometer) {
             //setTime();
            }
        });
    }
    public void timeOff(){
        time.stop();
    }
   /* public void Altitude(Location l) throws Exception {
        //altitude=Double.parseDouble(value);
        URL url = null;
        try {
            url = new URL("https://maps.googleapis.com/maps/api/elevation/xml?locations="+
                    l.getLatitude()+","+
                    l.getLongitude()+"&key=AIzaSyDoMcZTdogwsHzq5tT3mHpeeGzIvSTNypU");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        URLConnection connection = null;
        try {
            connection = url.openConnection();
        } catch (IOException e) {
            e.printStackTrace();
        }

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = null;
        try {
            db = dbf.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        Document document = null;
        try {
            document = db.parse(connection.getInputStream());
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //NodeList nodeList =
        String prova=document.getElementsByTagName("ElevationResponse").item(0).getAttributes().getNamedItem("name").toString();
        altitude=Double.parseDouble(prova);
        text.append("porcoddio");
    }*/
    public void setAltitude(double a){
        altitude=a;
    }
    public int getWeight(){
        return weight;
    }
    public double getDistance(){
        return distance;
    }
    public void setCalorie(double c){
        calories=calories+c;
    }
    public double getTime(){    //in minuti
        double millis = (SystemClock.elapsedRealtime() - time.getBase());
        return millis/60000;
    }
    public double getSpeed(){
        return speed;
    }
    public void setWeight(int w){
        weight=w;
    }
}
