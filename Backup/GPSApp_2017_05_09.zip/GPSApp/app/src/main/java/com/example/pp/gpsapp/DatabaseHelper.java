package com.example.pp.gpsapp;
/**
 * crea il database e usa le query per gestirlo
 */

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.sql.Time;
import java.util.Date;
//usa le virgolette solo nelle stringhe
public class DatabaseHelper extends SQLiteOpenHelper {

    static final String dbName = "Statistiche";

    public DatabaseHelper(Context context) {
        super(context, dbName, null, 1);
    }
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE Utente (\n" +
                "  IDUtente INT NOT NULL,\n" +
                "  Nome VARCHAR(45) NULL,\n" +
                "  Cognome VARCHAR(45) NULL,\n" +
                "  Sesso tinyint NULL,\n" +
                "  Altezza INT NULL,\n" +
                "  Peso INT NULL,\n" +
                "  PRIMARY KEY (IDUtente))");
            //sesso=1 è uomo
        db.execSQL("CREATE TABLE Attività (\n" +
                "  Data DATETIME NOT NULL,\n" +
                "  Durata TIME(7) NULL,\n" +
                "  Ditanza DOUBLE NULL,\n" +
                "  Calorie DOUBLE NULL,\n" +
                "  Velocità_media DOUBLE NULL,\n" +
                "  PRIMARY KEY (data))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
    //sesso=1 è uomo
    public void insertUtente(int id,  String nome, String cognome, int sesso, int altezza, int peso){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("INSERT INTO Utente (IDUtente, Nome, Cognome, Sesso, Altezza, Peso) VALUES ('"+id+"', '"+nome+"', '"+cognome+"', '"+sesso+"', '"+altezza+"', '"+peso+"');");
    }

    public void insertAttività(Date data, Time durata, float lungPerc, int calorie, float velmed){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("INSERT INTO Attività (Data,Durata,Lunghezza percorso, Calorie, Velocità media) VALUES("+data+", "+durata+","+lungPerc+","+calorie+","+velmed+");");
    }

    public void updateUtente(int id, String nome, String cognome, boolean sesso, int altezza, int peso){

        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("UPDATE Utente SET Nome="+nome +", Cognome="+cognome +", Sesso="+sesso +", Altezza="+altezza +", Peso="+peso +"  WHERE IDUtente="+id +";");
    }
    public int selectUtente(){
        SQLiteDatabase db = this.getWritableDatabase();
        int id=-1;
        Cursor cur=db.rawQuery("SELECT IDUtente, Peso FROM Utente",null);
        if (cur.moveToFirst()){
            do{
               id=cur.getInt(cur.getColumnIndex("IDUtente"));
            }while(cur.moveToNext());
        }
        cur.close();
        return id;
    }
    public String selectNome(){
        SQLiteDatabase db = this.getWritableDatabase();
        String s="John";
        Cursor cur=db.rawQuery("SELECT Nome FROM Utente",null);
        if (cur.moveToFirst()){
            do{
                s=cur.getString(cur.getColumnIndex("Nome"));
            }while(cur.moveToNext());
        }
        cur.close();
        return s;
    }
    public int selectWeight(){
        SQLiteDatabase db = this.getWritableDatabase();
        int weight=70;
        Cursor cur=db.rawQuery("SELECT Peso FROM Utente",null);
        if (cur.moveToFirst()){
            do{
                try {
                    weight = cur.getInt(cur.getColumnIndex("Peso"));   //cur.getColumnIndex("Peso")
                }catch(IllegalStateException ise){

                }
            }while(cur.moveToNext());
        }
        cur.close();
        return weight;
    }
    public String prova(){
        SQLiteDatabase db = this.getWritableDatabase();
        String prova="ERRORE";
        Cursor cur=db.rawQuery("SELECT * FROM Utente",null);
        if (cur.moveToFirst()){
            do{
                try {
                    prova=cur.getString(cur.getColumnIndex("Cognome"));
                }catch(IllegalStateException ise){

                }
            }while(cur.moveToNext());
        }
        cur.close();
        return prova;
    }
    public void reset(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from Utente");
        db.execSQL("delete from Attività");
    }
}