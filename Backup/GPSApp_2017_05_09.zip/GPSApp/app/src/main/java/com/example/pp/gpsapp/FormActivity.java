package com.example.pp.gpsapp;
/**
*questa classe crea il form e ne preleva i dati
 */
import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;

import static android.R.attr.value;

public class FormActivity extends Activity {
    private DatabaseHelper db;
    private EditText nome;
    private EditText  cognome;
    private CheckBox uomo;
    private CheckBox donna;
    private EditText  altezza;
    private EditText  peso;
    private Button submit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);
        //inizializzo cose
        Intent myIntent = new Intent(FormActivity.this, MapsActivity.class);
        db =new DatabaseHelper(FormActivity.this);
        nome=(EditText)findViewById(R.id.nome);
        cognome=(EditText)findViewById(R.id.cognome);
        uomo=(CheckBox)findViewById(R.id.uomo);
        donna=(CheckBox)findViewById(R.id.donna);
        altezza=(EditText)findViewById(R.id.altezza);
        peso=(EditText)findViewById(R.id.peso);
        submit=(Button)findViewById(R.id.submit);
        int idUtente=db.selectUtente();
        //se trova un utente può passare subito all'activity principale
        if(idUtente>=0) {
            FormActivity.this.startActivity(myIntent);
        }
        submit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(
                        getApplicationContext(),
                        MapsActivity.class
                );
                intent.putExtra("database", String.valueOf(db));
                int boolUomo=1;
                if(donna.isActivated()){
                    boolUomo=0;
                }
                try {
                    db.insertUtente(10, nome.getText().toString(), cognome.getText().toString(),
                            boolUomo, Integer.parseInt(altezza.getText().toString()), Integer.parseInt(peso.getText().toString()));
                }catch(NumberFormatException nfe){}
                startActivity(intent);
            }
        });
    }
}
