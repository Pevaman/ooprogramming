package com.example.pp.gpsapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.sql.Time;
import java.util.Date;

public class DatabaseHelper extends SQLiteOpenHelper {

    static final String dbName = "Statistiche";

    public DatabaseHelper(Context context) {
        super(context, dbName, null,1);
    }

    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE `Utente` (`IDUtente` INTEGER PRIMARY KEY AUTOINCREMENT,`Nome` VARCHAR(20), `Cognome` VARCHAR(40), `Sesso` BOOLEAN, `Altezza` INTEGER, `Peso` INTEGER );");
        db.execSQL("CREATE TABLE `Attività` (`Data` DATETIME PRIMARY KEY AUTOINCREMENT,`Durata` TIME, `Lunghezza percorso` FLOAT, `Calorie` INTEGER, `Velocità media` FLOAT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void insertUtente(int id,  String nome, String cognome, boolean sesso, int altezza, int peso){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("INSERT INTO 'Utente' (IDUtente, Nome, Cognome, Sesso, Altezza, Peso) VALUES('"+id+" "+nome+" "+cognome+" "+sesso+" "+altezza+" "+peso+"');");
    }

    public void insertAttività(Date data, Time durata, float lungperc, int calorie, float velmed){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("INSERT INTO 'Attività' (Data,Durata,Lunghezza percorso, Calorie, Velocità media) VALUES('"+data+" "+durata+" "+lungperc+" "+calorie+" "+velmed+"');");
    }

    public void updateUtente(int id, String nome, String cognome, boolean sesso, int altezza, int peso){

        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("UPDATE 'Utente' SET Nome="+nome +", Cognome="+cognome +", Sesso="+sesso +", Altezza="+altezza +", Peso="+peso +"  WHERE IDUtente="+id +";");
    }

    public void reset(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from Utente");
        db.execSQL("delete from Attività");
    }
}